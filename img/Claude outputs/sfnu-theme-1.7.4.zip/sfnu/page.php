<?php
/**
 * Static page — matches the original about.html body.
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<h1 class="page-title"><?php the_title(); ?></h1>

	<?php /* page-content is what the click-to-enlarge script looks for. */ ?>
	<div <?php post_class( 'page-content prose' ); ?>>
		<?php the_content(); ?>
	</div>

	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}

endwhile;

get_footer();
