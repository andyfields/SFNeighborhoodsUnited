<?php
/**
 * Comment area.
 *
 * Styled with the site's own type scale and rules so the discussion reads as
 * part of the page rather than a bolted-on panel.
 */

if ( post_password_required() ) {
	return;
}
?>

<section id="comments" class="comments prose">

	<?php if ( have_comments() ) : ?>

		<h2 class="comments-title">
			<?php
			$sfnu_count = (int) get_comments_number();
			printf(
				esc_html( _n( '%s comment', '%s comments', $sfnu_count, 'sfnu' ) ),
				esc_html( number_format_i18n( $sfnu_count ) )
			);
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'callback'    => 'sfnu_comment',
					'short_ping'  => true,
					'avatar_size' => 0,
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'prev_text' => __( '&larr; Older comments', 'sfnu' ),
				'next_text' => __( 'Newer comments &rarr;', 'sfnu' ),
			)
		);
		?>

	<?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() ) : ?>
		<p class="comments-closed"><?php esc_html_e( 'Comments are closed on this post.', 'sfnu' ); ?></p>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'title_reply'          => __( 'Leave a comment', 'sfnu' ),
			'title_reply_to'       => __( 'Reply to %s', 'sfnu' ),
			'cancel_reply_link'    => __( 'Cancel reply', 'sfnu' ),
			'label_submit'         => __( 'Post comment', 'sfnu' ),
			'class_submit'         => 'comment-submit',
			'title_reply_before'   => '<h2 id="reply-title" class="comment-reply-title">',
			'title_reply_after'    => '</h2>',
			'comment_notes_before' => '',
			'comment_notes_after'  => '',
			'comment_field'        => sprintf(
				'<p class="comment-form-comment"><label for="comment">%1$s</label>' .
				'<textarea id="comment" name="comment" rows="6" required></textarea></p>',
				esc_html__( 'Comment', 'sfnu' )
			),
		)
	);
	?>

</section>
