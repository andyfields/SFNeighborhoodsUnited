<?php
/**
 * 404 — matches the original 404.html.
 */

get_header();

$sfnu_about = get_page_by_path( 'about' );
?>

<h1 class="page-title"><?php esc_html_e( 'Page Not Found', 'sfnu' ); ?></h1>

<div class="prose">
	<p><?php esc_html_e( 'Sorry, the page you were trying to view does not exist.', 'sfnu' ); ?></p>
	<p>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Go to the blog', 'sfnu' ); ?></a>
		<?php if ( $sfnu_about ) : ?>
			<?php esc_html_e( 'or', 'sfnu' ); ?>
			<a href="<?php echo esc_url( get_permalink( $sfnu_about ) ); ?>"><?php esc_html_e( 'read about us', 'sfnu' ); ?></a>.
		<?php endif; ?>
	</p>
</div>

<?php get_footer(); ?>
