<?php
/**
 * GoatCounter page-view counting.
 *
 * Carries over the counter the static site used, so the traffic history stays
 * continuous across the move to WordPress. Jetpack Stats runs alongside it and
 * counts independently — the two will not agree exactly, which is normal.
 *
 * The endpoint is a customizer setting (Appearance > Customize > Site Identity),
 * so it can be changed or emptied without touching the theme. Empty means the
 * script is not loaded at all.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const SFNU_GOATCOUNTER_DEFAULT = 'https://sanfrancisconeighborhoodsunited.goatcounter.com/count';

/**
 * Print the counting script just before </body>.
 *
 * Skipped for logged-in users, so your own visits while editing do not inflate
 * the numbers. The static site had no way to exclude you; this does.
 */
function sfnu_goatcounter() {
	if ( is_user_logged_in() ) {
		return;
	}

	// Never count anything from the admin, feeds, or previews.
	if ( is_admin() || is_feed() || is_preview() || is_customize_preview() ) {
		return;
	}

	$endpoint = trim( (string) get_theme_mod( 'sfnu_goatcounter_url', SFNU_GOATCOUNTER_DEFAULT ) );
	if ( '' === $endpoint ) {
		return;
	}

	printf(
		'<script data-goatcounter="%s" async src="https://gc.zgo.at/count.js"></script>' . "\n",
		esc_url( $endpoint )
	);
}
add_action( 'wp_footer', 'sfnu_goatcounter', 100 );

/** The endpoint, alongside the theme's other site-wide settings. */
function sfnu_analytics_customize( $wp_customize ) {
	$wp_customize->add_setting(
		'sfnu_goatcounter_url',
		array(
			'default'           => SFNU_GOATCOUNTER_DEFAULT,
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		'sfnu_goatcounter_url',
		array(
			'label'       => __( 'GoatCounter endpoint', 'sfnu' ),
			'description' => __( 'Page-view counting, carried over from the static site. Leave empty to switch it off. Your own visits are never counted while you are logged in.', 'sfnu' ),
			'section'     => 'title_tagline',
			'type'        => 'url',
		)
	);
}
add_action( 'customize_register', 'sfnu_analytics_customize' );
