/*
 * Click any photo inside a post or page to see it full size; click again to
 * dismiss.
 *
 * Only images inside the body of an article (<article class="post">) or of a
 * page (.page-content) take part. Two exclusions matter: the thumbnails on the
 * blog index are links to their posts and must keep behaving as links, and the
 * comment area carries .prose like the body does, so the containers are named
 * explicitly rather than matched on that.
 */
(function () {
  'use strict';

  var bodies = document.querySelectorAll('article.post, .page-content');
  if (!bodies.length) return;

  var images = [];
  Array.prototype.forEach.call(bodies, function (body) {
    Array.prototype.push.apply(images, body.querySelectorAll('img'));
  });
  if (!images.length) return;

  var overlay = null;
  var lastFocused = null;

  function close() {
    if (!overlay) return;
    document.removeEventListener('keydown', onKeydown);
    document.body.classList.remove('has-lightbox');
    overlay.remove();
    overlay = null;
    if (lastFocused) {
      lastFocused.focus();
      lastFocused = null;
    }
  }

  function onKeydown(event) {
    if (event.key === 'Escape') close();
  }

  function open(image) {
    lastFocused = document.activeElement;

    overlay = document.createElement('div');
    overlay.className = 'lightbox';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', image.alt || 'Full size image');
    overlay.tabIndex = -1;

    var full = document.createElement('img');
    full.src = image.currentSrc || image.src;
    full.alt = image.alt;

    /*
     * Small images open at their own pixel size, which can be smaller than the
     * viewport allows. data-zoom on the source image scales that size up; the
     * max-width/max-height caps in the stylesheet still apply.
     *
     * The width attribute is consulted before naturalWidth, not after. A
     * lazy-loaded image that has not decoded yet reports naturalWidth 0, and
     * the old fallback to image.width then measured the rendered box instead —
     * so a picture displayed at a fifth of its size opened at a fifth of the
     * intended size. The attribute is the image's true width and is there from
     * the moment the markup parses.
     */
    var zoom = parseFloat(image.getAttribute('data-zoom'));
    if (zoom > 0) {
      var natural = parseInt(image.getAttribute('width'), 10)
        || image.naturalWidth
        || image.width;
      if (natural) full.style.width = Math.round(natural * zoom) + 'px';
    }

    overlay.appendChild(full);

    // A click anywhere, including on the image itself, dismisses it.
    overlay.addEventListener('click', close);

    document.body.appendChild(overlay);
    document.body.classList.add('has-lightbox');
    document.addEventListener('keydown', onKeydown);
    overlay.focus();
  }

  Array.prototype.forEach.call(images, function (image) {
    // Skip any image that is already inside a link.
    if (image.closest('a')) return;

    image.classList.add('is-zoomable');
    image.tabIndex = 0;
    image.setAttribute('role', 'button');
    image.setAttribute('aria-label', 'View full size: ' + (image.alt || 'image'));

    image.addEventListener('click', function () {
      if (overlay) {
        close();
      } else {
        open(image);
      }
    });

    image.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        open(image);
      }
    });
  });
})();
