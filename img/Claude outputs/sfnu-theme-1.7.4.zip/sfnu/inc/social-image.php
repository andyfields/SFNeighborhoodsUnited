<?php
/**
 * A default sharing image for pages that have none.
 *
 * When a link is posted to Facebook, LinkedIn or X, the site is scraped for an
 * og:image and that is the picture shown in the preview card. Jetpack fills
 * that in from a post's featured image, so the articles are covered. The blog
 * index has no featured image of its own, and Jetpack's own fallback chain ends
 * at a blank placeholder on s0.wp.com — so sharing the site's front page
 * produced a bare link with no picture at all.
 *
 * This supplies a real card for those cases: a 1200x630 image in the site's own
 * colours, which is the size all three platforms want for a full-width preview.
 *
 * The image is found by filename in the media library, so re-uploading it is
 * enough to change it and nothing here needs editing. A Customizer field
 * (Appearance > Customize > Site Identity) overrides that for anything else.
 *
 * To turn this off, delete the require_once line for this file in functions.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The media-library file used unless the Customizer says otherwise. */
const SFNU_SOCIAL_CARD_FILENAME = 'sfnu-social-card.png';

/** Jetpack's own placeholder, which is what we are replacing. */
const SFNU_SOCIAL_CARD_BLANK = 's0.wp.com/i/blank.jpg';

/**
 * The card, resolved once per request.
 *
 * Returns the URL along with the real pixel dimensions where they are known —
 * Facebook renders a compact thumbnail instead of a full-width card when it
 * cannot tell how big the image is before fetching it.
 *
 * @return array{url:string,width:int,height:int,alt:string}|null
 */
function sfnu_social_card() {
	static $card = false;

	if ( false !== $card ) {
		return $card;
	}

	$card = null;

	// An explicit URL set in the Customizer wins, wherever it points.
	$custom = trim( (string) get_theme_mod( 'sfnu_social_card_url', '' ) );
	if ( '' !== $custom ) {
		$id   = attachment_url_to_postid( $custom );
		$card = sfnu_social_card_from_id( $id ) ?? array(
			'url'    => $custom,
			'width'  => 0,
			'height' => 0,
			'alt'    => '',
		);
		return $card;
	}

	/*
	 * Otherwise find it by filename. sfnu_attachment_url_by_filename() belongs
	 * to the redirects module; look the attachment up directly if that file has
	 * been removed, so the two stay independent.
	 */
	$id = 0;
	if ( function_exists( 'sfnu_attachment_url_by_filename' ) ) {
		$url = sfnu_attachment_url_by_filename( SFNU_SOCIAL_CARD_FILENAME );
		if ( $url ) {
			$id = attachment_url_to_postid( $url );
		}
	}

	if ( ! $id ) {
		global $wpdb;
		$id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta}
				 WHERE meta_key = '_wp_attached_file'
				   AND ( meta_value = %s OR meta_value LIKE %s )
				 LIMIT 1",
				SFNU_SOCIAL_CARD_FILENAME,
				'%/' . $wpdb->esc_like( SFNU_SOCIAL_CARD_FILENAME )
			)
		);
	}

	$card = sfnu_social_card_from_id( $id );

	return $card;
}

/**
 * Build the card array from an attachment ID.
 *
 * @return array{url:string,width:int,height:int,alt:string}|null
 */
function sfnu_social_card_from_id( $id ) {
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}

	$src = wp_get_attachment_image_src( $id, 'full' );
	if ( ! $src ) {
		return null;
	}

	$alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
	if ( '' === $alt ) {
		$alt = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
	}

	return array(
		'url'    => $src[0],
		'width'  => (int) $src[1],
		'height' => (int) $src[2],
		'alt'    => $alt,
	);
}

/** Jetpack's documented hook for "no image was found for this page". */
function sfnu_social_card_default( $url ) {
	$card = sfnu_social_card();
	return $card ? $card['url'] : $url;
}
add_filter( 'jetpack_open_graph_image_default', 'sfnu_social_card_default' );

/*
 * There is a matching jetpack_open_graph_image_default_alt_text filter, and
 * hooking it was a mistake: Jetpack consults it for the fallback alt text
 * whenever the chosen image has none of its own, including when that image is a
 * post's featured photo. The imported photos have no alt text stored, so every
 * article ended up describing its photograph with the site's own tagline —
 * Facebook's debugger showed the injury photograph labelled "San Francisco
 * Neighborhoods United — See our Facebook group for more."
 *
 * The alt text is set in sfnu_social_card_tags() instead, which knows whether
 * the image actually is the card.
 */

/**
 * Last word on the finished tag list.
 *
 * Three cases end up here.
 *
 * An og:image that is missing, or is Jetpack's blank placeholder, is replaced
 * outright. And — the case that caught me out — an og:image the filter above
 * has *already* swapped for the card, but whose width and height still describe
 * whatever Jetpack was going to use. On the front page that left the card
 * declared as 200 by 200, and a declared size is what Facebook decides the
 * layout from, so it drew a small square instead of a full-width card. Matching
 * on our own URL fixes the dimensions whichever filter got there first.
 *
 * A post's own featured image is left alone.
 *
 * @param array $tags Open Graph tags Jetpack is about to print.
 * @return array
 */
function sfnu_social_card_tags( $tags ) {
	$current = isset( $tags['og:image'] ) ? $tags['og:image'] : '';

	// Jetpack allows an array of images; only step in when there is one image
	// and it is the placeholder or our own card, or none at all.
	if ( is_array( $current ) ) {
		if ( count( $current ) !== 1 ) {
			return $tags;
		}
		$current = (string) reset( $current );
	}

	$current = trim( (string) $current );

	$card = sfnu_social_card();

	$is_blank = ( '' === $current )
		|| false !== strpos( $current, SFNU_SOCIAL_CARD_BLANK );

	$is_ours = $card && $current === $card['url'];

	if ( ! $is_blank && ! $is_ours ) {
		return $tags;
	}

	if ( ! $card ) {
		return $tags;
	}

	$tags['og:image']     = $card['url'];
	$tags['og:image:alt'] = $card['alt'];

	if ( $card['width'] && $card['height'] ) {
		$tags['og:image:width']  = $card['width'];
		$tags['og:image:height'] = $card['height'];
	} else {
		unset( $tags['og:image:width'], $tags['og:image:height'] );
	}

	// X reads its own tags first and falls back to og:*; keep the two in step.
	if ( isset( $tags['twitter:image'] ) ) {
		$tags['twitter:image']     = $card['url'];
		$tags['twitter:image:alt'] = $card['alt'];
	}

	return $tags;
}
add_filter( 'jetpack_open_graph_tags', 'sfnu_social_card_tags', 20 );

/** The override, alongside the theme's other site-wide settings. */
function sfnu_social_card_customize( $wp_customize ) {
	$wp_customize->add_setting(
		'sfnu_social_card_url',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		'sfnu_social_card_url',
		array(
			'label'       => __( 'Default sharing image', 'sfnu' ),
			'description' => sprintf(
				/* translators: %s: the expected filename. */
				__( 'Shown in Facebook and LinkedIn previews for pages with no image of their own. Leave empty to use %s from the media library. 1200 by 630 pixels is the size all the major platforms want.', 'sfnu' ),
				SFNU_SOCIAL_CARD_FILENAME
			),
			'section'     => 'title_tagline',
			'type'        => 'url',
		)
	);
}
add_action( 'customize_register', 'sfnu_social_card_customize' );
