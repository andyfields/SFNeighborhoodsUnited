/*
 * Click any photo inside a post or page to see it full size; click again to
 * dismiss.
 *
 * Only images inside the body of an article (<article class="post">) or of a
 * page (.page-content) take part. Two exclusions matter: the thumbnails on the
 * blog index are links to their posts and must keep behaving as links, and the
 * comment area carries .prose like the body does, so the containers are named
 * explicitly rather than matched on that.
 */
(function () {
  'use strict';

  var bodies = document.querySelectorAll('article.post, .page-content');
  if (!bodies.length) return;

  var images = [];
  Array.prototype.forEach.call(bodies, function (body) {
    Array.prototype.push.apply(images, body.querySelectorAll('img'));
  });
  if (!images.length) return;

  var overlay = null;
  var lastFocused = null;

  /*
   * Ask for the picture at its own size rather than the page's.
   *
   * Jetpack's Site Accelerator rewrites every image through its CDN and
   * appends the size the page displays it at, so a 443-pixel screenshot shown
   * in a 278-pixel slot is delivered as a 278-pixel file. Opening that copy and
   * then scaling it up is not an enlargement at all — it is a blur. Dropping
   * the sizing parameters asks the CDN for the original.
   *
   * Anything else in the query string is left alone; ssl=1 in particular has to
   * survive or the request is refused.
   */
  var SIZING = ['resize', 'fit', 'w', 'h', 'crop', 'zoom'];

  function fullSize(url) {
    try {
      var parsed = new URL(url, window.location.href);
      SIZING.forEach(function (name) {
        parsed.searchParams.delete(name);
      });
      return parsed.href;
    } catch (error) {
      // Old browser, or a src this cannot parse: the page's own URL still works.
      return url;
    }
  }

  function close() {
    if (!overlay) return;
    document.removeEventListener('keydown', onKeydown);
    document.body.classList.remove('has-lightbox');
    overlay.remove();
    overlay = null;
    if (lastFocused) {
      lastFocused.focus();
      lastFocused = null;
    }
  }

  function onKeydown(event) {
    if (event.key === 'Escape') close();
  }

  function open(image) {
    lastFocused = document.activeElement;

    overlay = document.createElement('div');
    overlay.className = 'lightbox';
    overlay.setAttribute('role', 'dialog');
    overlay.setAttribute('aria-modal', 'true');
    overlay.setAttribute('aria-label', image.alt || 'Full size image');
    overlay.tabIndex = -1;

    var full = document.createElement('img');
    full.src = fullSize(image.currentSrc || image.src);
    full.alt = image.alt;

    /*
     * Small images open at their own pixel size, which can be smaller than the
     * viewport allows. data-zoom on the source image scales that size up.
     *
     * The width and height attributes are consulted before naturalWidth, not
     * after. A lazy-loaded image that has not decoded yet reports naturalWidth
     * 0, and the old fallback to image.width then measured the rendered box
     * instead — so a picture displayed at a fifth of its size opened at a fifth
     * of the intended size. The attributes are there from the moment the markup
     * parses.
     */
    var zoom = parseFloat(image.getAttribute('data-zoom'));
    if (zoom > 0) {
      var wide = parseInt(image.getAttribute('width'), 10)
        || image.naturalWidth
        || image.width;
      var tall = parseInt(image.getAttribute('height'), 10)
        || image.naturalHeight
        || image.height;

      if (wide && tall) {
        /*
         * Both dimensions are set, and the fit to the viewport is worked out
         * here rather than left to the stylesheet. The caps there are
         * max-width 94vw and max-height 94vh; with only a width given, a tall
         * picture that reached the height cap kept its full width and was
         * squashed. Sizing the box in script means neither cap ever has to
         * act, so the shape is right whatever the screen.
         */
        var fit = Math.min(
          1,
          (window.innerWidth * 0.94) / (wide * zoom),
          (window.innerHeight * 0.94) / (tall * zoom)
        );
        full.style.width = Math.round(wide * zoom * fit) + 'px';
        full.style.height = Math.round(tall * zoom * fit) + 'px';
      } else if (wide) {
        full.style.width = Math.round(wide * zoom) + 'px';
      }
    }

    overlay.appendChild(full);

    // A click anywhere, including on the image itself, dismisses it.
    overlay.addEventListener('click', close);

    document.body.appendChild(overlay);
    document.body.classList.add('has-lightbox');
    document.addEventListener('keydown', onKeydown);
    overlay.focus();
  }

  Array.prototype.forEach.call(images, function (image) {
    // Skip any image that is already inside a link.
    if (image.closest('a')) return;

    image.classList.add('is-zoomable');
    image.tabIndex = 0;
    image.setAttribute('role', 'button');
    image.setAttribute('aria-label', 'View full size: ' + (image.alt || 'image'));

    image.addEventListener('click', function () {
      if (overlay) {
        close();
      } else {
        open(image);
      }
    });

    image.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        open(image);
      }
    });
  });
})();
