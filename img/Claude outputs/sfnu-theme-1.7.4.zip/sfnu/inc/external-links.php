<?php
/**
 * External links open in a new tab.
 *
 * Applies to post and page content and to comment text, so it covers every
 * article already imported, the About page, and anything written later — with
 * nothing to remember when writing.
 *
 * Only links leaving this site are touched. Internal navigation, in-page
 * anchors, mailto: and tel: links are all left alone, as is any link that
 * already carries its own target.
 *
 * To turn this off, delete the require_once line for this file in functions.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is this href pointing somewhere off this site?
 */
function sfnu_is_external_url( $href ) {
	$href = trim( $href );

	// Anchors, mailto:, tel:, javascript: and protocol-relative junk.
	if ( '' === $href || preg_match( '#^(\#|mailto:|tel:|javascript:)#i', $href ) ) {
		return false;
	}

	// Root- or path-relative links are internal by definition.
	if ( ! preg_match( '#^https?://#i', $href ) ) {
		return false;
	}

	$host = wp_parse_url( $href, PHP_URL_HOST );
	$home = wp_parse_url( home_url(), PHP_URL_HOST );
	if ( ! $host || ! $home ) {
		return false;
	}

	$host = strtolower( preg_replace( '#^www\.#i', '', $host ) );
	$home = strtolower( preg_replace( '#^www\.#i', '', $home ) );

	return $host !== $home;
}

/**
 * Add target and rel to every external link in a block of HTML.
 *
 * @param string $html Content to filter.
 * @return string
 */
function sfnu_external_links( $html ) {
	if ( ! is_string( $html ) || false === stripos( $html, '<a ' ) ) {
		return $html;
	}

	return preg_replace_callback(
		'#<a\b([^>]*)>(.*?)</a>#is',
		'sfnu_external_link_callback',
		$html
	);
}

function sfnu_external_link_callback( $m ) {
	list( $whole, $attrs, $inner ) = $m;

	// Leave anything that has already decided for itself.
	if ( preg_match( '#\starget\s*=#i', $attrs ) ) {
		return $whole;
	}

	if ( ! preg_match( '#\shref\s*=\s*(["\'])(.*?)\1#i', $attrs, $href ) ) {
		return $whole;
	}

	if ( ! sfnu_is_external_url( html_entity_decode( $href[2], ENT_QUOTES, 'UTF-8' ) ) ) {
		return $whole;
	}

	// Merge with any rel the link already has rather than replacing it —
	// WordPress adds rel="nofollow ugc" to links inside comments.
	$rel = array( 'noopener', 'noreferrer' );
	if ( preg_match( '#\srel\s*=\s*(["\'])(.*?)\1#i', $attrs, $existing ) ) {
		$rel   = array_unique( array_merge( preg_split( '#\s+#', trim( $existing[2] ) ), $rel ) );
		$attrs = preg_replace( '#\srel\s*=\s*(["\']).*?\1#i', '', $attrs );
	}

	$attrs = rtrim( $attrs ) . ' target="_blank" rel="' . esc_attr( implode( ' ', array_filter( $rel ) ) ) . '"';

	/*
	 * A new tab opening unannounced is disorienting for anyone who cannot see it
	 * happen, so links with visible text get a note only screen readers reach.
	 * Skipped when the link wraps an image, or already says as much.
	 */
	$note = __( '(opens in a new tab)', 'sfnu' );
	if ( '' !== trim( wp_strip_all_tags( $inner ) ) && false === stripos( $inner, $note ) ) {
		$inner .= '<span class="visually-hidden"> ' . esc_html( $note ) . '</span>';
	}

	return '<a' . $attrs . '>' . $inner . '</a>';
}

add_filter( 'the_content', 'sfnu_external_links', 20 );
add_filter( 'comment_text', 'sfnu_external_links', 40 );
