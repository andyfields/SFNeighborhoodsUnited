<?php
/**
 * Single post — matches the original posts/*.html body.
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>

	<?php
	// the_content() filters must run before the subtitle can be split off it.
	list( $sfnu_subtitle, $sfnu_body ) = sfnu_split_subtitle(
		apply_filters( 'the_content', get_the_content() )
	);
	?>
	<article <?php post_class( 'post prose post--centered-head' ); ?>>
		<h1 class="page-title"><?php the_title(); ?></h1>

		<?php echo wp_kses_post( $sfnu_subtitle ); ?>

		<?php sfnu_post_meta(); ?>

		<?php echo $sfnu_body; // phpcs:ignore WordPress.Security.EscapeOutput — already filtered content. ?>

		<?php
		wp_link_pages(
			array(
				'before' => '<p class="post-pages">' . esc_html__( 'Pages:', 'sfnu' ) . ' ',
				'after'  => '</p>',
			)
		);
		?>
	</article>

	<?php
	if ( comments_open() || get_comments_number() ) {
		comments_template();
	}
	?>

	<p class="back-link"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">&larr; <?php esc_html_e( 'Back to the blog', 'sfnu' ); ?></a></p>

	<?php
endwhile;

get_footer();
