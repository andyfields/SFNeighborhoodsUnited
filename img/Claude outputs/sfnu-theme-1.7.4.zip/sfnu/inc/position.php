<?php
/**
 * Manual post ordering.
 *
 * The blog index is ordered by importance rather than by date. Each post
 * carries a Position number, stored in WordPress's native `menu_order` column
 * (unused for posts, so nothing is displaced).
 *
 *   Position 100, 200 …  ordered top to bottom, lowest first.
 *   Position 0          not set — these fall below every positioned post and
 *                       sort newest first among themselves. New posts start
 *                       here, so publishing never silently reshuffles the page.
 *
 * The import numbers posts 100, 200, 300 …, which leaves 99 free slots
 * between any two posts and 99 above the top one, so inserting a post is
 * always a matter of picking a number rather than renumbering the page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -------------------------------------------------------------------------
 * Front end ordering
 * ---------------------------------------------------------------------- */

/**
 * Order the blog index by position, then by date.
 *
 * WP_Query cannot express "0 sorts last", so the ORDER BY is written directly.
 */
function sfnu_order_by_position( $query ) {
	if ( is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( ! $query->is_home() && ! $query->is_archive() ) {
		return;
	}
	add_filter( 'posts_orderby', 'sfnu_position_orderby', 10, 2 );
}
add_action( 'pre_get_posts', 'sfnu_order_by_position' );

function sfnu_position_orderby( $orderby, $query ) {
	// One query only — remove immediately so nothing else inherits it.
	remove_filter( 'posts_orderby', 'sfnu_position_orderby', 10 );

	global $wpdb;
	return "CASE WHEN {$wpdb->posts}.menu_order = 0 THEN 1 ELSE 0 END ASC, "
		. "{$wpdb->posts}.menu_order ASC, "
		. "{$wpdb->posts}.post_date DESC";
}

/* -------------------------------------------------------------------------
 * Keeping a post off the blog index
 * ---------------------------------------------------------------------- */

/**
 * Post meta marking a post as not for the blog index. The key exists only on
 * hidden posts, so the query below is a plain NOT EXISTS.
 */
const SFNU_HIDE_META = '_sfnu_hide_from_index';

function sfnu_register_hide_meta() {
	register_post_meta(
		'post',
		SFNU_HIDE_META,
		array(
			'type'          => 'boolean',
			'single'        => true,
			'show_in_rest'  => true,
			'auth_callback' => function ( $allowed, $meta_key, $post_id ) {
				return current_user_can( 'edit_post', $post_id );
			},
		)
	);
}
add_action( 'init', 'sfnu_register_hide_meta' );

/**
 * Drop hidden posts from the blog index.
 *
 * Only the index is filtered. The post keeps its URL and anyone holding the
 * link reaches it as before — which is the point — and it is still listed in
 * the RSS feed, the sitemap and on-site search results. Say so out loud,
 * because "not on the blog page" is easily mistaken for "unpublished".
 */
function sfnu_hide_from_index( $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_home() ) {
		return;
	}

	$meta_query   = (array) $query->get( 'meta_query' );
	$meta_query[] = array(
		'key'     => SFNU_HIDE_META,
		'compare' => 'NOT EXISTS',
	);
	$query->set( 'meta_query', $meta_query );
}
add_action( 'pre_get_posts', 'sfnu_hide_from_index' );

/* -------------------------------------------------------------------------
 * Editor: a Position box on the post screen
 * ---------------------------------------------------------------------- */

function sfnu_position_meta_box() {
	add_meta_box(
		'sfnu-position',
		__( 'Position', 'sfnu' ),
		'sfnu_position_meta_box_render',
		'post',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'sfnu_position_meta_box' );

function sfnu_position_meta_box_render( $post ) {
	wp_nonce_field( 'sfnu_position_save', 'sfnu_position_nonce' );
	?>
	<p>
		<label for="sfnu-position-field" class="screen-reader-text">
			<?php esc_html_e( 'Position on the blog index', 'sfnu' ); ?>
		</label>
		<input type="number" id="sfnu-position-field" name="sfnu_position"
		       value="<?php echo esc_attr( $post->menu_order ); ?>"
		       min="0" step="1" style="width:6em">
	</p>
	<p class="description">
		<?php esc_html_e( 'Lower numbers appear higher on the blog index — existing posts are 100, 200, 300 and so on. Use 50 to put this post at the top, or 150 to slot it between the first and second. Leave at 0 to sort by date, below everything you have positioned.', 'sfnu' ); ?>
	</p>

	<?php
	/*
	 * Marks that the checkbox was on screen. Quick Edit carries the position
	 * field and its nonce but not this one, so without the marker a Quick Edit
	 * save — which never sends an unticked checkbox — would quietly clear the
	 * setting on every post it touched.
	 */
	?>
	<input type="hidden" name="sfnu_hide_present" value="1">
	<p>
		<label for="sfnu-hide-field">
			<input type="checkbox" id="sfnu-hide-field" name="sfnu_hide_from_index" value="1"
			       <?php checked( get_post_meta( $post->ID, SFNU_HIDE_META, true ) ); ?>>
			<?php esc_html_e( 'Keep off the blog index', 'sfnu' ); ?>
		</label>
	</p>
	<p class="description">
		<?php esc_html_e( 'The post stays published and anyone with the link still reaches it. It is only taken off the blog page. It remains in the RSS feed, the sitemap and site search.', 'sfnu' ); ?>
	</p>
	<?php
}

/** Save the checkbox. Only when the box was actually on the screen. */
function sfnu_hide_save( $post_id ) {
	if ( ! isset( $_POST['sfnu_hide_present'], $_POST['sfnu_position_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_key( $_POST['sfnu_position_nonce'] ), 'sfnu_position_save' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	if ( empty( $_POST['sfnu_hide_from_index'] ) ) {
		delete_post_meta( $post_id, SFNU_HIDE_META );
	} else {
		update_post_meta( $post_id, SFNU_HIDE_META, 1 );
	}
}
add_action( 'save_post_post', 'sfnu_hide_save' );

/**
 * Save the field by filtering the post data on its way in, which avoids a
 * second write and the recursion that comes with it.
 */
function sfnu_position_save( $data, $postarr ) {
	if ( 'post' !== $data['post_type'] ) {
		return $data;
	}
	if ( ! isset( $postarr['sfnu_position'], $postarr['sfnu_position_nonce'] ) ) {
		return $data;
	}
	if ( ! wp_verify_nonce( $postarr['sfnu_position_nonce'], 'sfnu_position_save' ) ) {
		return $data;
	}
	if ( ! empty( $postarr['ID'] ) && ! current_user_can( 'edit_post', $postarr['ID'] ) ) {
		return $data;
	}

	$data['menu_order'] = max( 0, (int) $postarr['sfnu_position'] );
	return $data;
}
add_filter( 'wp_insert_post_data', 'sfnu_position_save', 10, 2 );

/* -------------------------------------------------------------------------
 * Posts list: a sortable Position column, editable from Quick Edit
 * ---------------------------------------------------------------------- */

function sfnu_position_column( $columns ) {
	$out = array();
	foreach ( $columns as $key => $label ) {
		$out[ $key ] = $label;
		if ( 'title' === $key ) {
			$out['sfnu_position'] = __( 'Position', 'sfnu' );
		}
	}
	return $out;
}
add_filter( 'manage_post_posts_columns', 'sfnu_position_column' );

function sfnu_position_column_content( $column, $post_id ) {
	if ( 'sfnu_position' !== $column ) {
		return;
	}
	$order = (int) get_post_field( 'menu_order', $post_id );
	printf(
		'<span class="sfnu-position-value">%s</span>',
		$order ? esc_html( $order ) : '<em style="opacity:.6">' . esc_html__( 'by date', 'sfnu' ) . '</em>'
	);

	// Worth seeing at a glance: a post missing from the blog page looks like a
	// mistake unless the list says it is deliberate.
	if ( get_post_meta( $post_id, SFNU_HIDE_META, true ) ) {
		printf(
			'<br><em style="opacity:.6">%s</em>',
			esc_html__( 'off the index', 'sfnu' )
		);
	}
}
add_action( 'manage_post_posts_custom_column', 'sfnu_position_column_content', 10, 2 );

function sfnu_position_sortable( $columns ) {
	$columns['sfnu_position'] = 'menu_order';
	return $columns;
}
add_filter( 'manage_edit-post_sortable_columns', 'sfnu_position_sortable' );

/** Sort the posts list by position when the admin orders by that column. */
function sfnu_position_admin_order( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}
	if ( 'menu_order' === $query->get( 'orderby' ) ) {
		$query->set( 'orderby', 'menu_order' );
	}
}
add_action( 'pre_get_posts', 'sfnu_position_admin_order' );

/** The Quick Edit field. */
function sfnu_position_quick_edit( $column, $post_type ) {
	if ( 'sfnu_position' !== $column || 'post' !== $post_type ) {
		return;
	}
	wp_nonce_field( 'sfnu_position_save', 'sfnu_position_nonce' );
	?>
	<fieldset class="inline-edit-col-right">
		<div class="inline-edit-col">
			<label style="display:flex;align-items:center;gap:.5em">
				<span class="title"><?php esc_html_e( 'Position', 'sfnu' ); ?></span>
				<input type="number" name="sfnu_position" class="sfnu-position-input"
				       min="0" step="1" value="" style="width:6em">
			</label>
		</div>
	</fieldset>
	<?php
}
add_action( 'quick_edit_custom_box', 'sfnu_position_quick_edit', 10, 2 );

/** Quick Edit opens with empty fields; copy the row's value into it. */
function sfnu_position_quick_edit_js( $hook ) {
	if ( 'edit.php' !== $hook || 'post' !== get_current_screen()->post_type ) {
		return;
	}

	$js = <<<'JS'
( function () {
	if ( ! window.inlineEditPost ) { return; }
	var original = inlineEditPost.edit;

	inlineEditPost.edit = function ( id ) {
		var result = original.apply( this, arguments );
		var postId = typeof id === 'object' ? this.getId( id ) : id;
		if ( ! postId ) { return result; }

		var row   = document.getElementById( 'post-' + postId );
		var field = document.querySelector( '#edit-' + postId + ' .sfnu-position-input' );
		if ( ! row || ! field ) { return result; }

		var cell = row.querySelector( '.sfnu-position-value' );
		var text = cell ? cell.textContent.trim() : '';
		field.value = /^\d+$/.test( text ) ? text : '0';
		return result;
	};
}() );
JS;

	wp_add_inline_script( 'inline-edit-post', $js );
}
add_action( 'admin_enqueue_scripts', 'sfnu_position_quick_edit_js' );
