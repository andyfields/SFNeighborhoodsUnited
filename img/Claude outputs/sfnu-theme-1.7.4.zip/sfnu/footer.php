<?php
/**
 * Site footer — the shared footer block from the original static pages.
 *
 * The contact address comes from the "Contact email" setting under
 * Appearance > Customize > Site Identity, falling back to the site admin
 * address so the footer is never empty.
 */

$sfnu_contact = get_theme_mod( 'sfnu_contact_email', get_option( 'admin_email' ) );
?>
		</div>
	</main>

	<!-- ===== SHARED FOOTER — keep identical on every page ===== -->
	<footer class="site-footer">
		<div class="wrap">
			<p class="footer-title"><?php bloginfo( 'name' ); ?></p>
			<?php if ( $sfnu_contact ) : ?>
				<p class="footer-contact">
					<?php esc_html_e( 'Contact:', 'sfnu' ); ?>
					<a href="mailto:<?php echo esc_attr( antispambot( $sfnu_contact ) ); ?>"><?php echo esc_html( antispambot( $sfnu_contact ) ); ?></a>
				</p>
			<?php endif; ?>
		</div>
	</footer>
	<!-- ===== END SHARED FOOTER ===== -->

<?php wp_footer(); ?>
</body>
</html>
