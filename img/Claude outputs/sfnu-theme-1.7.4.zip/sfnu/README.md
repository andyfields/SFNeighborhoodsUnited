# SF Neighborhoods United — WordPress theme

The hand-built static site, converted to a WordPress theme. `style.css` is the
original stylesheet with two sections appended (comments, and a couple of rules
WordPress needs); every template emits the same markup and class names the
static pages used, so the CSS did not have to be rewritten.

## Install

Appearance → Themes → Add New → Upload Theme → choose `sfnu-theme.zip` → Activate.
(Uploading a theme requires a paid WordPress.com plan. On self-hosted WordPress
there is no restriction.)

## After activating

1. **Settings → General** — set the Tagline to `See our Facebook group for more.`
   (plain text; WordPress strips HTML from this field).
2. **Appearance → Customize → Site Identity** — three fields this theme adds:
   - *Contact email* — shown in the footer.
   - *Tagline link text* — the words in the tagline to link. Default:
     `Facebook group`.
   - *Tagline link URL* — the Facebook group address.
3. **Settings → Permalinks** — choose *Day and name* to match the slugs in the
   import file.
4. **Appearance → Menus** — optional. Without a menu the header shows Blog and
   About automatically.

## Post order

The blog index is ordered by **Position**, not by date.

- Each post has a *Position* box in the editor sidebar, and a sortable
  *Position* column on the Posts list that is editable from Quick Edit.
- Lower numbers sit higher on the page. The import numbers them 100, 200,
  300 … in the order they appeared on the old `index.html`. That leaves 99
  free numbers between any two posts, and 99 above the top one, so inserting
  a post is always a matter of picking a number — never renumbering the page.
  To put a post at the very top use 50; to slot it between the first and
  second use 150.
- Position **0** means "not positioned". Those posts fall below every
  positioned one and sort newest first among themselves. New posts start at 0,
  so publishing never silently reshuffles the page — the post appears at the
  bottom until you give it a number.

The number is stored in WordPress's native `menu_order` column, which posts do
not otherwise use, so nothing else is affected and the value survives export
and re-import.

## External links

Links pointing off the site open in a new tab, with `rel="noopener noreferrer"`
and a screen-reader-only "(opens in a new tab)" note. This is applied to post
and page content and to comment text, so it covers existing articles, the About
page and anything written later — nothing to remember when writing.

Internal links, in-page anchors, `mailto:` and `tel:` links are left alone, as
is any link that already carries its own `target`.

To switch it off, delete the `require_once` line for `inc/external-links.php`
in `functions.php`.

## Analytics

Two counters run:

- **Jetpack Stats** — WordPress.com's own, in the Stats screen. Per-post views,
  referrers, search terms, countries. Nothing to configure.
- **GoatCounter** — carried over from the static site so the traffic history
  stays continuous. The endpoint is under Appearance → Customize → Site
  Identity; empty it to switch GoatCounter off.

Your own visits are not counted by GoatCounter while you are logged in — the
static site had no way to exclude you, so its numbers include your own reading.
The two counters measure differently and will never agree exactly.

## Redirects from the old site

`inc/redirects.php` maps the static site's URLs onto the WordPress ones with
301s, so links already shared to Facebook and Nextdoor, and everything Google
has indexed, keep working after the domain moves:

    /posts/YYYY-MM-DD-slug.html  ->  /YYYY/MM/DD/slug/
    /index.html                  ->  /
    /about.html                  ->  /about/
    /img/<file>                  ->  the copy in the media library

They only fire on requests WordPress would otherwise 404, so a real page always
wins and normal traffic is untouched. Query strings are carried across, so
campaign tags survive the hop. A path that matches the shape but names
something that does not exist still 404s rather than guessing.

These depend on the permalink structure staying **Day and name**.

One gap worth knowing about: on WordPress.com the `/img/` rules never fire,
because the server answers requests ending in an image extension itself and
never hands them to WordPress. The post and page redirects — the ones carrying
the shared links and search results — are unaffected.

## The sharing image

When a link is posted to Facebook, LinkedIn or X, those sites scrape the page
for an `og:image` and that is the picture in the preview card. Jetpack takes it
from the post's featured image, so the articles are covered. The blog index has
no featured image of its own, and Jetpack's fallback chain ends at a blank
placeholder on `s0.wp.com` — so sharing the front page produced a bare link with
no picture.

`inc/social-image.php` supplies a real card in those cases. It looks for
`sfnu-social-card.png` in the media library, so re-uploading that file under the
same name is all it takes to change the picture — no code to edit. Appearance >
Customize > Site Identity has a **Default sharing image** field that overrides
the lookup with any URL.

A post's own featured image is never touched. Only a missing image, or Jetpack's
placeholder, is replaced. The card's real pixel dimensions are printed alongside
it, because Facebook falls back to a small square thumbnail when it cannot tell
how big an image is before fetching it.

1200 by 630 is the size to use. Facebook ignores anything under 200 pixels on a
side, and shows a compact thumbnail rather than a full-width card for anything
narrower than about 445 pixels or taller than it is wide.

## Notes

- **`wpautop` is switched off for post content.** The imported posts are already
  marked up with `<p>` tags, and leaving it on turned every wrapped line in the
  source HTML into a `<br>`. Comments still get it, since those are typed as
  plain text.
- **Index thumbnails** use the post's featured image, falling back to the first
  image in the post body. The imported posts originally had no featured image,
  so they relied on the fallback; each one now has a featured image set to the
  same picture, which makes the sharing preview deliberate rather than whatever
  happens to appear first in the article. The fallback stays for anything added
  later without one.
- **Post subtitles**: a leading `<p class="post-subtitle">` is lifted out of the
  content and placed above the date, matching the original page order.
- **`inc/position.php`** holds everything to do with manual ordering. Deleting
  that one `require` line in `functions.php` reverts the site to date order.
- **Click-to-enlarge** applies to images in the body of a post *and* of a page,
  so supporting pages carrying screenshots or tables work the same way. The
  script looks for `article.post` and `.page-content` by name rather than for
  `.prose`, because the comment area carries `.prose` too and commenters'
  avatars should not become buttons. Images already wrapped in a link are
  skipped, which is what keeps the blog-index thumbnails behaving as links.
