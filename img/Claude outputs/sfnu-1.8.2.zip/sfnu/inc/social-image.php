<?php
/**
 * A default sharing image for pages that have none.
 *
 * When a link is posted to Facebook, LinkedIn or X, the site is scraped for an
 * og:image and that is the picture shown in the preview card. Jetpack fills
 * that in from a post's featured image, so the articles are covered. The blog
 * index has no featured image of its own, and Jetpack's own fallback chain ends
 * at a blank placeholder on s0.wp.com — so sharing the site's front page
 * produced a bare link with no picture at all.
 *
 * This supplies a real card for those cases: a 1200x630 image in the site's own
 * colours, which is the size all three platforms want for a full-width preview.
 *
 * The image is found by filename in the media library, so re-uploading it is
 * enough to change it and nothing here needs editing. A Customizer field
 * (Appearance > Customize > Site Identity) overrides that for anything else.
 *
 * To turn this off, delete the require_once line for this file in functions.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The media-library file used unless the Customizer says otherwise. */
const SFNU_SOCIAL_CARD_FILENAME = 'sfnu-social-card.png';

/**
 * Per-post override: an attachment ID to hand the sharing platforms instead of
 * whatever this page would otherwise offer.
 *
 * The featured image already serves two masters — it is the thumbnail on the
 * blog index and, through Jetpack, the picture on a Facebook card — and the two
 * want different things. The index wants the photograph itself, small. Facebook
 * only draws a card full width at about 1200x630, so a tall screenshot gets
 * rendered as a postage stamp beside the headline. This lets a post keep its
 * own picture on the site and send a properly shaped card out instead.
 */
const SFNU_SOCIAL_IMAGE_META = '_sfnu_social_image';

/** Jetpack's own placeholder, which is what we are replacing. */
const SFNU_SOCIAL_CARD_BLANK = 's0.wp.com/i/blank.jpg';

/**
 * The card, resolved once per request.
 *
 * Returns the URL along with the real pixel dimensions where they are known —
 * Facebook renders a compact thumbnail instead of a full-width card when it
 * cannot tell how big the image is before fetching it.
 *
 * @return array{url:string,width:int,height:int,alt:string}|null
 */
function sfnu_social_card() {
	static $card = false;

	if ( false !== $card ) {
		return $card;
	}

	$card = null;

	// An explicit URL set in the Customizer wins, wherever it points.
	$custom = trim( (string) get_theme_mod( 'sfnu_social_card_url', '' ) );
	if ( '' !== $custom ) {
		$id   = attachment_url_to_postid( $custom );
		$card = sfnu_social_card_from_id( $id ) ?? array(
			'url'    => $custom,
			'width'  => 0,
			'height' => 0,
			'alt'    => '',
		);
		return $card;
	}

	/*
	 * Otherwise find it by filename. sfnu_attachment_url_by_filename() belongs
	 * to the redirects module; look the attachment up directly if that file has
	 * been removed, so the two stay independent.
	 */
	$id = 0;
	if ( function_exists( 'sfnu_attachment_url_by_filename' ) ) {
		$url = sfnu_attachment_url_by_filename( SFNU_SOCIAL_CARD_FILENAME );
		if ( $url ) {
			$id = attachment_url_to_postid( $url );
		}
	}

	if ( ! $id ) {
		global $wpdb;
		$id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta}
				 WHERE meta_key = '_wp_attached_file'
				   AND ( meta_value = %s OR meta_value LIKE %s )
				 LIMIT 1",
				SFNU_SOCIAL_CARD_FILENAME,
				'%/' . $wpdb->esc_like( SFNU_SOCIAL_CARD_FILENAME )
			)
		);
	}

	$card = sfnu_social_card_from_id( $id );

	return $card;
}

/**
 * Build the card array from an attachment ID.
 *
 * @return array{url:string,width:int,height:int,alt:string}|null
 */
function sfnu_social_card_from_id( $id ) {
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}

	$src = wp_get_attachment_image_src( $id, 'full' );
	if ( ! $src ) {
		return null;
	}

	$alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
	if ( '' === $alt ) {
		$alt = wp_strip_all_tags( (string) get_bloginfo( 'name' ) );
	}

	return array(
		'url'    => $src[0],
		'width'  => (int) $src[1],
		'height' => (int) $src[2],
		'alt'    => $alt,
	);
}

/** Jetpack's documented hook for "no image was found for this page". */
function sfnu_social_card_default( $url ) {
	$card = sfnu_social_card();
	return $card ? $card['url'] : $url;
}
add_filter( 'jetpack_open_graph_image_default', 'sfnu_social_card_default' );

/*
 * There is a matching jetpack_open_graph_image_default_alt_text filter, and
 * hooking it was a mistake: Jetpack consults it for the fallback alt text
 * whenever the chosen image has none of its own, including when that image is a
 * post's featured photo. The imported photos have no alt text stored, so every
 * article ended up describing its photograph with the site's own tagline —
 * Facebook's debugger showed the injury photograph labelled "San Francisco
 * Neighborhoods United — See our Facebook group for more."
 *
 * The alt text is set in sfnu_social_card_tags() instead, which knows whether
 * the image actually is the card.
 */

/**
 * Last word on the finished tag list.
 *
 * Three cases end up here.
 *
 * An og:image that is missing, or is Jetpack's blank placeholder, is replaced
 * outright. And — the case that caught me out — an og:image the filter above
 * has *already* swapped for the card, but whose width and height still describe
 * whatever Jetpack was going to use. On the front page that left the card
 * declared as 200 by 200, and a declared size is what Facebook decides the
 * layout from, so it drew a small square instead of a full-width card. Matching
 * on our own URL fixes the dimensions whichever filter got there first.
 *
 * A post's own featured image is left alone. A single post or page with *no*
 * featured image is the fourth case, added later: see the comment on
 * $is_unchosen below.
 *
 * @param array $tags Open Graph tags Jetpack is about to print.
 * @return array
 */
function sfnu_social_card_tags( $tags ) {
	// A picture chosen for this post specifically settles the matter.
	$chosen = sfnu_post_social_image();
	if ( $chosen ) {
		return sfnu_apply_social_image( $tags, $chosen );
	}

	$current = isset( $tags['og:image'] ) ? $tags['og:image'] : '';

	// Jetpack allows an array of images; only step in when there is one image
	// and it is the placeholder or our own card, or none at all.
	if ( is_array( $current ) ) {
		if ( count( $current ) !== 1 ) {
			return $tags;
		}
		$current = (string) reset( $current );
	}

	$current = trim( (string) $current );

	$card = sfnu_social_card();

	$is_blank = ( '' === $current )
		|| false !== strpos( $current, SFNU_SOCIAL_CARD_BLANK );

	$is_ours = $card && $current === $card['url'];

	/*
	 * Jetpack's chain is: the featured image, then the first <img> in the post
	 * body, then the default. The middle step is the problem. A post with no
	 * featured image still gets a card built from whatever picture happens to
	 * appear first in the text, and on an article made of evidence screenshots
	 * that is a 350-pixel video crop — Facebook draws it as a small square and
	 * the link reads as broken.
	 *
	 * No featured image on a single post or page is read here as "the author
	 * nominated nothing", so the site card stands in. Setting a featured image
	 * is how a post opts out and chooses its own picture, which is the same
	 * gesture that controls the blog-index thumbnail, so the two stay in step.
	 */
	$is_unchosen = is_singular() && ! has_post_thumbnail();

	if ( ! $is_blank && ! $is_ours && ! $is_unchosen ) {
		return $tags;
	}

	if ( ! $card ) {
		return $tags;
	}

	return sfnu_apply_social_image( $tags, $card );
}
add_filter( 'jetpack_open_graph_tags', 'sfnu_social_card_tags', 20 );

/**
 * Put one image into the tag list, dimensions and alt text together.
 *
 * The dimensions matter as much as the URL: a declared size is what Facebook
 * lays the card out from, before it has fetched anything. Leaving a previous
 * image's width and height behind is how the card once went out declared 200
 * by 200 and was drawn as a small square.
 *
 * @param array $tags  Open Graph tags Jetpack is about to print.
 * @param array $image {url, width, height, alt}.
 * @return array
 */
function sfnu_apply_social_image( $tags, $image ) {
	$tags['og:image']     = $image['url'];
	$tags['og:image:alt'] = $image['alt'];

	if ( $image['width'] && $image['height'] ) {
		$tags['og:image:width']  = $image['width'];
		$tags['og:image:height'] = $image['height'];
	} else {
		unset( $tags['og:image:width'], $tags['og:image:height'] );
	}

	// X reads its own tags first and falls back to og:*; keep the two in step.
	if ( isset( $tags['twitter:image'] ) ) {
		$tags['twitter:image']     = $image['url'];
		$tags['twitter:image:alt'] = $image['alt'];
	}

	return $tags;
}

/* -------------------------------------------------------------------------
 * Per-post sharing image
 * ---------------------------------------------------------------------- */

/**
 * The sharing image chosen for the post being viewed, if there is one.
 *
 * @return array{url:string,width:int,height:int,alt:string}|null
 */
function sfnu_post_social_image() {
	if ( ! is_singular() ) {
		return null;
	}

	$id = (int) get_post_meta( get_queried_object_id(), SFNU_SOCIAL_IMAGE_META, true );
	if ( ! $id ) {
		return null;
	}

	// Falls through to the usual chain if the attachment has since been deleted,
	// rather than printing a tag that points at nothing.
	return sfnu_social_card_from_id( $id );
}

function sfnu_register_social_image_meta() {
	$args = array(
		'type'          => 'integer',
		'single'        => true,
		'show_in_rest'  => true,
		'auth_callback' => function ( $allowed, $meta_key, $post_id ) {
			return current_user_can( 'edit_post', $post_id );
		},
	);
	register_post_meta( 'post', SFNU_SOCIAL_IMAGE_META, $args );
	register_post_meta( 'page', SFNU_SOCIAL_IMAGE_META, $args );
}
add_action( 'init', 'sfnu_register_social_image_meta' );

function sfnu_social_image_meta_box() {
	foreach ( array( 'post', 'page' ) as $screen ) {
		add_meta_box(
			'sfnu-social-image',
			__( 'Sharing image', 'sfnu' ),
			'sfnu_social_image_meta_box_render',
			$screen,
			'side',
			'low'
		);
	}
}
add_action( 'add_meta_boxes', 'sfnu_social_image_meta_box' );

function sfnu_social_image_meta_box_render( $post ) {
	wp_nonce_field( 'sfnu_social_image_save', 'sfnu_social_image_nonce' );

	$id  = (int) get_post_meta( $post->ID, SFNU_SOCIAL_IMAGE_META, true );
	$src = $id ? wp_get_attachment_image_src( $id, 'medium' ) : false;
	?>
	<p>
		<label for="sfnu-social-image-field">
			<?php esc_html_e( 'Media ID', 'sfnu' ); ?>
		</label>
		<input type="number" id="sfnu-social-image-field" name="sfnu_social_image"
		       value="<?php echo $id ? esc_attr( $id ) : ''; ?>"
		       min="0" step="1" style="width:6em">
	</p>
	<?php if ( $src ) : ?>
		<p><img src="<?php echo esc_url( $src[0] ); ?>" alt="" style="max-width:100%;height:auto"></p>
		<p class="description">
			<?php
			printf(
				/* translators: %1$d: width in pixels. %2$d: height in pixels. */
				esc_html__( 'Currently %1$d by %2$d.', 'sfnu' ),
				(int) $src[1],
				(int) $src[2]
			);
			if ( (int) $src[1] < 600 ) {
				echo ' ' . esc_html__( 'Facebook only draws a full-width card at around 1200 by 630; narrower than that and it shows a small square instead.', 'sfnu' );
			}
			?>
		</p>
	<?php endif; ?>
	<p class="description">
		<?php esc_html_e( 'Sent to Facebook, LinkedIn and X in place of the featured image, which goes on carrying the blog index thumbnail. Leave empty to use the featured image for both. The ID is in the address bar when you open the picture in the media library.', 'sfnu' ); ?>
	</p>
	<?php
}

function sfnu_social_image_save( $post_id ) {
	if ( ! isset( $_POST['sfnu_social_image_nonce'] ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_key( $_POST['sfnu_social_image_nonce'] ), 'sfnu_social_image_save' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$id = isset( $_POST['sfnu_social_image'] ) ? absint( $_POST['sfnu_social_image'] ) : 0;
	if ( $id ) {
		update_post_meta( $post_id, SFNU_SOCIAL_IMAGE_META, $id );
	} else {
		delete_post_meta( $post_id, SFNU_SOCIAL_IMAGE_META );
	}
}
add_action( 'save_post_post', 'sfnu_social_image_save' );
add_action( 'save_post_page', 'sfnu_social_image_save' );

/** The override, alongside the theme's other site-wide settings. */
function sfnu_social_card_customize( $wp_customize ) {
	$wp_customize->add_setting(
		'sfnu_social_card_url',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		'sfnu_social_card_url',
		array(
			'label'       => __( 'Default sharing image', 'sfnu' ),
			'description' => sprintf(
				/* translators: %s: the expected filename. */
				__( 'Shown in Facebook and LinkedIn previews for pages with no image of their own. Leave empty to use %s from the media library. 1200 by 630 pixels is the size all the major platforms want.', 'sfnu' ),
				SFNU_SOCIAL_CARD_FILENAME
			),
			'section'     => 'title_tagline',
			'type'        => 'url',
		)
	);
}
add_action( 'customize_register', 'sfnu_social_card_customize' );
