<?php
/**
 * Redirects from the old static site's URLs.
 *
 * The static site used paths like
 *
 *     /posts/2026-09-11-a-very-dangerous-park.html
 *     /index.html
 *     /about.html
 *     /img/injury.jpg
 *
 * WordPress uses /2026/09/11/a-very-dangerous-park/ and friends. Every link
 * shared to Facebook or Nextdoor, every search result and every bookmark still
 * points at the old form, so without these the whole existing link graph 404s
 * the moment the domain moves.
 *
 * Each rule sends a 301 (permanent), which is what tells search engines to
 * transfer the old page's standing to the new URL rather than treating it as a
 * new page that has lost its history.
 *
 * These only fire for requests WordPress would otherwise fail to match, so they
 * cost nothing on normal traffic and cannot shadow a real page.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Work out where an old path should go, or null to leave it alone.
 *
 * Split out from the redirect itself so it can be reasoned about — and tested —
 * without involving headers.
 *
 * @param string $path Request path, no query string, leading slash.
 * @return string|null Destination URL, or null for "not one of ours".
 */
function sfnu_legacy_target( $path ) {
	$path = '/' . ltrim( (string) $path, '/' );

	// /index.html — the old blog index.
	if ( preg_match( '#^/index\.html$#i', $path ) ) {
		return home_url( '/' );
	}

	// /about.html and any other top-level page: match on the slug.
	if ( preg_match( '#^/([a-z0-9-]+)\.html$#i', $path, $m ) ) {
		$page = get_page_by_path( strtolower( $m[1] ) );
		if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
			return get_permalink( $page );
		}
		return null;
	}

	// /posts/YYYY-MM-DD-slug.html — the old post URLs.
	if ( preg_match( '#^/posts/\d{4}-\d{2}-\d{2}-(.+)\.html$#i', $path, $m ) ) {
		$post = get_page_by_path( strtolower( $m[1] ), OBJECT, 'post' );
		if ( $post instanceof WP_Post && 'publish' === $post->post_status ) {
			return get_permalink( $post );
		}
		return null;
	}

	/*
	 * /img/whatever.jpg — the old image folder. Nothing on this site links here
	 * any more, but other people's pages and Facebook's cache still might, so
	 * point them at the copy now in the media library.
	 */
	if ( preg_match( '#^/img/([^/]+)$#i', $path, $m ) ) {
		$url = sfnu_attachment_url_by_filename( $m[1] );
		return $url ? $url : null;
	}

	return null;
}

/**
 * Find an attachment by its original filename.
 *
 * @return string|null
 */
function sfnu_attachment_url_by_filename( $filename ) {
	global $wpdb;

	$filename = sanitize_file_name( rawurldecode( $filename ) );
	if ( '' === $filename ) {
		return null;
	}

	$id = wp_cache_get( 'sfnu_legacy_img_' . $filename, 'sfnu' );

	if ( false === $id ) {
		// _wp_attached_file holds e.g. "2026/09/injury.jpg".
		$id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta}
				 WHERE meta_key = '_wp_attached_file'
				   AND ( meta_value = %s OR meta_value LIKE %s )
				 LIMIT 1",
				$filename,
				'%/' . $wpdb->esc_like( $filename )
			)
		);
		wp_cache_set( 'sfnu_legacy_img_' . $filename, $id, 'sfnu', HOUR_IN_SECONDS );
	}

	return $id ? wp_get_attachment_url( $id ) : null;
}

/**
 * Send the redirect.
 *
 * Runs on template_redirect and only when WordPress has already decided the
 * request is a 404, so a real page always wins.
 */
function sfnu_legacy_redirect() {
	if ( ! is_404() || is_admin() ) {
		return;
	}

	$request = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
	$path    = wp_parse_url( $request, PHP_URL_PATH );
	if ( ! $path ) {
		return;
	}

	$target = sfnu_legacy_target( $path );
	if ( ! $target ) {
		return;
	}

	// Carry any query string across, so ?utm_source=… survives the hop.
	$query = wp_parse_url( $request, PHP_URL_QUERY );
	if ( $query ) {
		$target .= ( str_contains( $target, '?' ) ? '&' : '?' ) . $query;
	}

	wp_safe_redirect( $target, 301 );
	exit;
}
add_action( 'template_redirect', 'sfnu_legacy_redirect', 1 );
