<?php
/**
 * San Francisco Neighborhoods United — theme functions.
 *
 * This theme reproduces the hand-built static site. The stylesheet is the
 * original site's style.css, unchanged apart from an appended section for the
 * comment area, so the markup emitted by these templates deliberately matches
 * the class names the original HTML used.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SFNU_VERSION', '1.8.1' );

// Manual ordering of the blog index.
require_once get_theme_file_path( 'inc/position.php' );

// External links open in a new tab.
require_once get_theme_file_path( 'inc/external-links.php' );

// GoatCounter page-view counting.
require_once get_theme_file_path( 'inc/analytics.php' );

// Redirects from the old static site's URLs.
require_once get_theme_file_path( 'inc/redirects.php' );

// A default sharing image for pages with none of their own.
require_once get_theme_file_path( 'inc/social-image.php' );

/* -------------------------------------------------------------------------
 * Setup
 * ---------------------------------------------------------------------- */

function sfnu_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support(
		'html5',
		array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script' )
	);

	register_nav_menus(
		array( 'primary' => __( 'Primary navigation', 'sfnu' ) )
	);
}
add_action( 'after_setup_theme', 'sfnu_setup' );

function sfnu_content_width() {
	$GLOBALS['content_width'] = 1000;
}
add_action( 'after_setup_theme', 'sfnu_content_width', 0 );

/* -------------------------------------------------------------------------
 * Assets
 * ---------------------------------------------------------------------- */

function sfnu_assets() {
	wp_enqueue_style( 'sfnu-style', get_stylesheet_uri(), array(), SFNU_VERSION );

	// Click-to-enlarge, on article bodies and page bodies alike. Supporting
	// pages carry evidence — screenshots, tables — that is unreadable at the
	// page's own width, so it matters there as much as in a post.
	if ( is_singular( array( 'post', 'page' ) ) ) {
		wp_enqueue_script(
			'sfnu-app',
			get_theme_file_uri( 'js/app.js' ),
			array(),
			SFNU_VERSION,
			true
		);
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'sfnu_assets' );

/**
 * Theme colour and icons, matching the original site's <head>.
 * Skipped when a Site Icon has been set in the customizer, so the admin
 * setting wins if it is ever used.
 */
function sfnu_head_meta() {
	echo '<meta name="theme-color" content="#e7e2dd">' . "\n";

	if ( has_site_icon() ) {
		return;
	}
	$assets = get_theme_file_uri( 'assets' );
	printf( '<link rel="icon" href="%s/favicon.ico" sizes="any">' . "\n", esc_url( $assets ) );
	printf( '<link rel="icon" href="%s/icon.svg" type="image/svg+xml">' . "\n", esc_url( $assets ) );
	printf( '<link rel="apple-touch-icon" href="%s/icon.png">' . "\n", esc_url( $assets ) );
}
add_action( 'wp_head', 'sfnu_head_meta' );

/* -------------------------------------------------------------------------
 * Jetpack
 * ---------------------------------------------------------------------- */

/**
 * Keep this theme's own comment form.
 *
 * Jetpack's Comments module replaces the theme's form with one served in an
 * iframe from jetpack.wordpress.com. That form ignores this theme's styling and,
 * because the response lands inside the iframe, the surrounding page never
 * reloads — a commenter sees "Comment Sent" and no sign of their comment, with
 * nothing to tell them to refresh.
 *
 * Jetpack checks this filter before discarding the theme's output, so returning
 * false leaves the form in comments.php in place, posting normally to
 * wp-comments-post.php and reloading the page with the comment on it.
 *
 * Trade-off: this also removes Jetpack's WordPress.com and Facebook login
 * buttons. Commenting stays open by name and email.
 *
 * @see https://github.com/Automattic/jetpack — modules/comments/comments.php
 */
add_filter( 'jetpack_comment_form_enabled_for_post', '__return_false' );
add_filter( 'jetpack_comment_form_enabled_for_page', '__return_false' );

/**
 * Switch off the "Related" block Jetpack appends below each post.
 *
 * WordPress.com gives no setting for this: Settings > Reading offers only the
 * block's display options, and its enable flag is a hidden field fixed at on.
 * So it is turned off here instead.
 *
 * To bring it back, delete these two functions. To keep it on most posts and
 * suppress it on a few, test for them:
 *
 *     if ( is_single( array( 557 ) ) ) {
 *         $options['enabled'] = false;
 *     }
 *
 * @see https://developer.jetpack.com/docs/customization/related-posts/
 *
 * @param array $options Jetpack's related-posts options.
 * @return array
 */
function sfnu_disable_related_posts( $options ) {
	$options['enabled'] = false;
	return $options;
}
add_filter( 'jetpack_relatedposts_filter_options', 'sfnu_disable_related_posts' );

/* -------------------------------------------------------------------------
 * Helpers
 * ---------------------------------------------------------------------- */

/**
 * Thumbnail for a blog-index card.
 *
 * Prefers the featured image. Imported posts have none, so it falls back to
 * the first <img> in the post body, which is what the original index used.
 *
 * @return array{url:string,alt:string,width:string,height:string}|null
 */
function sfnu_card_image( $post = null ) {
	$post = get_post( $post );
	if ( ! $post ) {
		return null;
	}

	if ( has_post_thumbnail( $post ) ) {
		$id  = get_post_thumbnail_id( $post );
		$src = wp_get_attachment_image_src( $id, 'large' );
		if ( $src ) {
			return array(
				'url'    => $src[0],
				'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
				'width'  => (string) $src[1],
				'height' => (string) $src[2],
			);
		}
	}

	if ( ! preg_match( '/<img\b[^>]*>/i', $post->post_content, $tag ) ) {
		return null;
	}
	if ( ! preg_match( '/\ssrc=["\']([^"\']+)["\']/i', $tag[0], $src ) ) {
		return null;
	}

	$dim = array( 'width' => '', 'height' => '' );
	foreach ( array( 'width', 'height' ) as $attr ) {
		if ( preg_match( '/\s' . $attr . '=["\']?(\d+)/i', $tag[0], $m ) ) {
			$dim[ $attr ] = $m[1];
		}
	}

	return array(
		'url'    => $src[1],
		'alt'    => '',
		'width'  => $dim['width'],
		'height' => $dim['height'],
	);
}

/** The date line used under every title, matching the original markup. */
function sfnu_post_meta( $post = null ) {
	$post = get_post( $post );
	printf(
		'<p class="post-meta"><time datetime="%1$s">%2$s</time></p>',
		esc_attr( get_the_date( 'Y-m-d', $post ) ),
		esc_html( get_the_date( 'F j, Y', $post ) )
	);
}

/**
 * Post bodies arrive fully marked up — from the import, and from the block
 * editor afterwards — so wpautop has nothing useful to add. Left on, it turns
 * every wrapped line in the source HTML into a <br>, which breaks the line
 * breaks in .post-note and inside figure captions.
 */
function sfnu_unhook_wpautop() {
	remove_filter( 'the_content', 'wpautop' );
	remove_filter( 'the_excerpt', 'wpautop' );
	remove_filter( 'comment_text', 'wpautop' );
	// Comments are typed as plain text, so they do still need the paragraphs.
	add_filter( 'comment_text', 'wpautop', 30 );
}
add_action( 'init', 'sfnu_unhook_wpautop' );

/**
 * Split a leading <p class="post-subtitle"> off the post body.
 *
 * The original pages order the head as title, subtitle, date. The importer
 * leaves the subtitle at the top of the content, so the template pulls it back
 * out to keep that order.
 *
 * @return array{0:string,1:string} Subtitle markup (may be empty), then the rest.
 */
function sfnu_split_subtitle( $content ) {
	$pattern = '#^\s*(<p[^>]*\bclass=(["\'])[^"\']*\bpost-subtitle\b[^"\']*\2[^>]*>.*?</p>)#is';

	if ( preg_match( $pattern, $content, $m ) ) {
		return array( $m[1], substr( $content, strlen( $m[0] ) ) );
	}
	return array( '', $content );
}

/** Excerpts on the index are plain sentences — no trailing ellipsis link. */
function sfnu_excerpt_more() {
	return '';
}
add_filter( 'excerpt_more', 'sfnu_excerpt_more' );

/**
 * The site tagline, with one phrase inside it turned into a link.
 *
 * WordPress escapes HTML in the tagline when the option is saved, so markup
 * cannot simply be typed into Settings > General. Instead the tagline stays
 * plain text and two customizer fields say which phrase to link and where to.
 */
function sfnu_tagline_html() {
	$text = get_option( 'blogdescription' );
	if ( ! $text ) {
		return '';
	}

	// The option is stored already escaped; render it as the text it is.
	$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );

	$phrase = trim( (string) get_theme_mod( 'sfnu_tagline_link_text', 'Facebook group' ) );
	$url    = trim( (string) get_theme_mod( 'sfnu_tagline_link_url', '' ) );

	if ( ! $phrase || ! $url ) {
		return esc_html( $text );
	}

	$at = strpos( $text, $phrase );
	if ( false === $at ) {
		return esc_html( $text );
	}

	// Opens in a new tab: the link leads off-site, and losing the blog to go to
	// Facebook is not what a reader clicking it expects. rel="noopener" is what
	// stops the opened page from getting a handle on this one.
	return esc_html( substr( $text, 0, $at ) )
		. '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">'
		. esc_html( $phrase )
		. '<span class="visually-hidden"> ' . esc_html__( '(opens in a new tab)', 'sfnu' ) . '</span>'
		. '</a>'
		. esc_html( substr( $text, $at + strlen( $phrase ) ) );
}

/** Navigation fallback, so the theme works before a menu is assigned. */
function sfnu_default_nav() {
	$items = array(
		home_url( '/' ) => __( 'Blog', 'sfnu' ),
	);

	$about = get_page_by_path( 'about' );
	if ( $about ) {
		$items[ get_permalink( $about ) ] = get_the_title( $about );
	}

	echo '<nav class="site-nav" aria-label="Main">';
	foreach ( $items as $url => $label ) {
		$current = ( untrailingslashit( $url ) === untrailingslashit( sfnu_current_url() ) )
			? ' aria-current="page"'
			: '';
		printf(
			'<a class="nav-link" href="%s"%s>%s</a>',
			esc_url( $url ),
			$current, // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html( $label )
		);
	}
	echo '</nav>';
}

function sfnu_current_url() {
	if ( is_front_page() || is_home() ) {
		return home_url( '/' );
	}
	$id = get_queried_object_id();
	return $id ? (string) get_permalink( $id ) : home_url( '/' );
}

/* -------------------------------------------------------------------------
 * Comments
 * ---------------------------------------------------------------------- */

/** One comment, in the site's own markup rather than WordPress's default. */
function sfnu_comment( $comment, $args, $depth ) {
	$tag = ( 'div' === $args['style'] ) ? 'div' : 'li';
	?>
	<<?php echo esc_attr( $tag ); ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( 'comment-item' ); ?>>
		<article class="comment-body">
			<header class="comment-head">
				<p class="comment-author"><?php echo get_comment_author_link(); // phpcs:ignore WordPress.Security.EscapeOutput ?></p>
				<p class="comment-meta-line">
					<time datetime="<?php comment_time( 'c' ); ?>">
						<?php echo esc_html( get_comment_date( 'F j, Y' ) ); ?>
					</time>
				</p>
			</header>

			<?php if ( '0' === $comment->comment_approved ) : ?>
				<p class="comment-awaiting"><?php esc_html_e( 'Your comment is awaiting approval.', 'sfnu' ); ?></p>
			<?php endif; ?>

			<div class="comment-text"><?php comment_text(); ?></div>

			<p class="comment-actions">
				<?php
				comment_reply_link(
					array_merge(
						$args,
						array(
							'depth'     => $depth,
							'max_depth' => $args['max_depth'],
							'reply_text' => __( 'Reply', 'sfnu' ),
						)
					)
				);
				?>
			</p>
		</article>
	<?php
	// WordPress closes the tag for us when using the list walker.
}

/* -------------------------------------------------------------------------
 * Customizer: the footer contact address
 * ---------------------------------------------------------------------- */

function sfnu_customize_register( $wp_customize ) {
	$wp_customize->add_setting(
		'sfnu_contact_email',
		array(
			'default'           => get_option( 'admin_email' ),
			'sanitize_callback' => 'sanitize_email',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		'sfnu_contact_email',
		array(
			'label'       => __( 'Contact email', 'sfnu' ),
			'description' => __( 'Shown in the site footer.', 'sfnu' ),
			'section'     => 'title_tagline',
			'type'        => 'email',
		)
	);

	$wp_customize->add_setting(
		'sfnu_tagline_link_text',
		array(
			'default'           => 'Facebook group',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		'sfnu_tagline_link_text',
		array(
			'label'       => __( 'Tagline link text', 'sfnu' ),
			'description' => __( 'Words inside the tagline to turn into a link. WordPress strips HTML from the tagline itself, so the link is set here.', 'sfnu' ),
			'section'     => 'title_tagline',
			'type'        => 'text',
		)
	);

	$wp_customize->add_setting(
		'sfnu_tagline_link_url',
		array(
			'default'           => '',
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		'sfnu_tagline_link_url',
		array(
			'label'       => __( 'Tagline link URL', 'sfnu' ),
			'description' => __( 'Where that phrase should link to. Leave empty for a plain-text tagline.', 'sfnu' ),
			'section'     => 'title_tagline',
			'type'        => 'url',
		)
	);
}
add_action( 'customize_register', 'sfnu_customize_register' );
