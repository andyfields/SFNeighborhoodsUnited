<?php
/**
 * Site header — the shared header block from the original static pages.
 */
?>
<!doctype html>
<html class="no-js" <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

	<a class="visually-hidden focusable" href="#main"><?php esc_html_e( 'Skip to content', 'sfnu' ); ?></a>

	<!-- ===== SHARED HEADER — keep identical on every page ===== -->
	<header class="site-header">
		<div class="wrap">
			<div class="site-branding">
				<p class="site-title">
					<?php if ( is_front_page() && is_home() ) : ?>
						<?php bloginfo( 'name' ); ?>
					<?php else : ?>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
					<?php endif; ?>
				</p>
				<?php $sfnu_tagline = sfnu_tagline_html(); ?>
				<?php if ( $sfnu_tagline ) : ?>
					<p class="site-tagline"><?php echo wp_kses_post( $sfnu_tagline ); ?></p>
				<?php endif; ?>
			</div>

			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => 'nav',
					'container_class' => 'site-nav',
					'container_aria_label' => __( 'Main', 'sfnu' ),
					'menu_class'     => 'site-nav-list',
					'depth'          => 1,
					'fallback_cb'    => 'sfnu_default_nav',
				)
			);
			?>
		</div>
	</header>
	<!-- ===== END SHARED HEADER ===== -->

	<main id="main">
		<div class="wrap">
