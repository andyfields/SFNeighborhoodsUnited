<?php
/**
 * Blog index — the summary-card list from the original index.html.
 */

get_header();
?>

<h1 class="page-title">
	<?php
	if ( is_home() && ! is_front_page() ) {
		single_post_title();
	} elseif ( is_archive() ) {
		the_archive_title();
	} elseif ( is_search() ) {
		/* translators: %s: search query. */
		printf( esc_html__( 'Search results for %s', 'sfnu' ), '&ldquo;' . esc_html( get_search_query() ) . '&rdquo;' );
	} else {
		esc_html_e( 'Blog', 'sfnu' );
	}
	?>
</h1>

<?php if ( have_posts() ) : ?>

	<div class="post-list">
		<?php
		while ( have_posts() ) :
			the_post();
			$sfnu_img = sfnu_card_image();
			?>
			<article <?php post_class( 'post-summary' ); ?>>
				<?php if ( $sfnu_img ) : ?>
					<a class="post-summary-thumb" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
						<img src="<?php echo esc_url( $sfnu_img['url'] ); ?>"
						     alt=""
						     <?php if ( $sfnu_img['width'] ) : ?>width="<?php echo esc_attr( $sfnu_img['width'] ); ?>"<?php endif; ?>
						     <?php if ( $sfnu_img['height'] ) : ?>height="<?php echo esc_attr( $sfnu_img['height'] ); ?>"<?php endif; ?>
						     loading="lazy">
					</a>
				<?php endif; ?>

				<div class="post-summary-body">
					<h2 class="post-summary-title">
						<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
					</h2>

					<?php sfnu_post_meta(); ?>

					<?php $sfnu_excerpt = get_the_excerpt(); ?>
					<?php if ( $sfnu_excerpt ) : ?>
						<p class="post-excerpt"><?php echo wp_kses_post( $sfnu_excerpt ); ?></p>
					<?php endif; ?>

					<p>
						<a class="read-more" href="<?php the_permalink(); ?>">
							<?php esc_html_e( 'Read more', 'sfnu' ); ?>
							<span class="visually-hidden"><?php echo esc_html( get_the_title() ); ?></span>
						</a>
					</p>
				</div>
			</article>
		<?php endwhile; ?>
	</div>

	<?php
	the_posts_pagination(
		array(
			'mid_size'  => 1,
			'prev_text' => __( '&larr; Newer posts', 'sfnu' ),
			'next_text' => __( 'Older posts &rarr;', 'sfnu' ),
		)
	);
	?>

<?php else : ?>

	<p class="empty-state"><?php esc_html_e( 'No posts yet.', 'sfnu' ); ?></p>

<?php endif; ?>

<?php get_footer(); ?>
